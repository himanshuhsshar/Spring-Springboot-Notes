package com.athena.pharamcy.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@Scope("refresh")
public class Store {
	@Value("${store.storeNo}")
	private String storeNo;
	@Value("${store.storeName}")
	private String storeName;
	@Value("${store.storeManager}")
	private String storeManager;
	@Value("${store.openHours}")
	private int openHours;
	@Value("${store.openMinutes}")
	private int openMinutes;
	@Value("${store.closingHours}")
	private int closingHours;
	@Value("${store.closingMinutes}")
	private int closingMinutes;
	@Value("${store.location}")
	private String location;
}
