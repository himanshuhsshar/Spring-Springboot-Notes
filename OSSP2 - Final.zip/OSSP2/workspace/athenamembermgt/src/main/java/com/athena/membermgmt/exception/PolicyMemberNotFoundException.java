package com.athena.membermgmt.exception;

public class PolicyMemberNotFoundException extends RuntimeException {

	public PolicyMemberNotFoundException(String message) {
		super(message);
	}

}
