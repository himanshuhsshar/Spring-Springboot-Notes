package com.athena.pharamcy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AthenaPharmacyApplication {
	public static void main(String[] args) {
		SpringApplication.run(AthenaPharmacyApplication.class, args);
	}
}
