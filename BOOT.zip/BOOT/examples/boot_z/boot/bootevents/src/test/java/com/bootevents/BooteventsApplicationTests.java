package com.bootevents;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooteventsApplicationTests {

	@Test
	void contextLoads() {
	}

}
