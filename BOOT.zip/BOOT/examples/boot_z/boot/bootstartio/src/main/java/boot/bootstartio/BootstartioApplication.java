package boot.bootstartio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootstartioApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootstartioApplication.class, args);
	}

}
