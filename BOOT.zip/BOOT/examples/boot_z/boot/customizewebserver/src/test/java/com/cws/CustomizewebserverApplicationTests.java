package com.cws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomizewebserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
