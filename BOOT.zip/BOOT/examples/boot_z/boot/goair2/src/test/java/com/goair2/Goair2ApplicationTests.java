package com.goair2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Goair2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
