package com.goair2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Goair2Application {

	public static void main(String[] args) {
		SpringApplication.run(Goair2Application.class, args);
	}

}
