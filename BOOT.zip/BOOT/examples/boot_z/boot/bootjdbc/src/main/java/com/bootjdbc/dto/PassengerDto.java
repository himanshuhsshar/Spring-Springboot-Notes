package com.bootjdbc.dto;

import lombok.Data;

@Data
public class PassengerDto {
	private int passengerNo;
	private String fullname;
	private int age;
	private String gender;
}
