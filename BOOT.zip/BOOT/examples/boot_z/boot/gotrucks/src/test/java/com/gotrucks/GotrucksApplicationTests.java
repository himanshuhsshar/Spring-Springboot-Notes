package com.gotrucks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GotrucksApplicationTests {

	@Test
	void contextLoads() {
	}

}
