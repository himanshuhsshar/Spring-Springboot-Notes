package com.aa.beans;

public class Calculator {
	public int add(int a, int b) {
		int sum = 0;
		sum = a + b;
		System.out.println("in add()");
		return sum;
	}
}
