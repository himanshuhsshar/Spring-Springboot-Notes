package com.ara.exception;

public class WeakKeyException extends RuntimeException {

	public WeakKeyException(String message) {
		super(message);
	}

}
