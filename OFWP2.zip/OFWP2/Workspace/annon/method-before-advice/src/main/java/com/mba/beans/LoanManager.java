package com.mba.beans;

import org.springframework.stereotype.Component;

@Component
public class LoanManager {
	public boolean approveLoan(long loanNo) {
		return true;
	}
}
