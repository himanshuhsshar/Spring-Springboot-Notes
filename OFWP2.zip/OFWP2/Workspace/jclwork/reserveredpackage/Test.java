package com.pcl.main;

public class Test {
	public static void main(String[] args) {
		java.lang.StringHelper sh = new java.lang.StringHelper();
		int len = sh.getLength();
		System.out.println("len : " + len);
	}
}