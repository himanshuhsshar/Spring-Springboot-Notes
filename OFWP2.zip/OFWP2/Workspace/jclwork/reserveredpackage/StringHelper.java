package java.lang;

public class StringHelper {
	public int getLength() {
		return 10;
	}
}