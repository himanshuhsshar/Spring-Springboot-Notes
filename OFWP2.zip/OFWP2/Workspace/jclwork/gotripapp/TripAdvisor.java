package com.gotrip.beans;

import java.util.*;

public class TripAdvisor {
	public List<String> getPopularPlaces(String city) {
		return Arrays.asList(new String[]{"Charminar", "Golconda Fort", "Birla Temple"});
	}
}