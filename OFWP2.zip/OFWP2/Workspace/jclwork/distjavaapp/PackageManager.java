package com.gofit.packages;
public class PackageManager {
	public void showPackages() {
		System.out.println("Monthly Package starts at: 250 rupees");
		System.out.println("Quaterly Package starts at: 600 rupees");		
	}
}