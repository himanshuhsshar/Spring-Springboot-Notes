package com.up.products;
public class Claypot {
	public int capacity() {		
		return 20;
	}
}