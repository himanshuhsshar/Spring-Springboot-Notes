package com.awareinjection.beans;

public interface IEngine {
	void start();
}
