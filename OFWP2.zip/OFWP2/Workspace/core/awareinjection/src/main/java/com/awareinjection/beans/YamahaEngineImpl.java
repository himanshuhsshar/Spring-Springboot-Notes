package com.awareinjection.beans;

public class YamahaEngineImpl implements IEngine {

	@Override
	public void start() {
		System.out.println("Yamaha engine started..");
	}

}
