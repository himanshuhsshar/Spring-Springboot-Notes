package com.awareinjection.beans;

public class SuzkiEngineImpl implements IEngine {

	@Override
	public void start() {
		System.out.println("Suzki engine started..");
	}

}
