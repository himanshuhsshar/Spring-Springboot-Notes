package com.annotation5.lookup;

public interface IEngine {
	void start();
}
