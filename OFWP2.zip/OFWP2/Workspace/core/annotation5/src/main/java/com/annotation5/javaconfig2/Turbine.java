package com.annotation5.javaconfig2;

// no source code
public class Turbine {
	public void produce() {
		System.out.println("producing power...");
	}
}
