package com.annotation5.javaconfig;

// no source code
public class Microphone {
	public void capture() {
		System.out.println("capturing the voice");
	}
}
