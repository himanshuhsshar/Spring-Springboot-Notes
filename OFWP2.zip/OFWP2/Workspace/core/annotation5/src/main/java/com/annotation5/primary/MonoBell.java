package com.annotation5.primary;

// no source code
public class MonoBell implements Bell {

	@Override
	public void ring() {
		System.out.println("ringing mono bell");
	}

}
