package com.annotation5.primary;

public interface Bell {
	void ring();
}
