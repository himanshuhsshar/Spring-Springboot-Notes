package com.annotation5.importresource;

// no source code
public class HeatingElement {
	public void heat(int degrees) {
		System.out.println("heating to degrees : " + degrees);
	}
}
