package com.annotation5.xmlstereotype;

// no source code
public class ToyCar {
	private int id;
	private String color;

	public void go() {
		System.out.println("moving with id : " + id + " color : " + color);
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setColor(String color) {
		this.color = color;
	}

}
