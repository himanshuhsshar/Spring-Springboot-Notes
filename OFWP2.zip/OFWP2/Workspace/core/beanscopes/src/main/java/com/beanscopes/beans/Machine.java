package com.beanscopes.beans;

public class Machine {
	public void run() {
		System.out.println("running");
	}
}
