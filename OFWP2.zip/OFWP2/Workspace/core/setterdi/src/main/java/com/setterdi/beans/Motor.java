package com.setterdi.beans;

public interface Motor {
	void run();
}
