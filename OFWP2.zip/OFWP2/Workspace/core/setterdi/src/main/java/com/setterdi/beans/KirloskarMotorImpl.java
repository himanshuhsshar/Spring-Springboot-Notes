package com.setterdi.beans;

public class KirloskarMotorImpl implements Motor {
	@Override
	public void run() {
		System.out.println("kirloskar motor running...");
	}
}
