package com.setterdi.beans;

public class CromptonMotorImpl implements Motor {

	@Override
	public void run() {
		System.out.println("crompton motor running...");
	}

}
