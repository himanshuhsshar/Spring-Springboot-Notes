package com.ifmi.ejb;

public interface StockTradeManager {
	double getStockPrice(String stockName);
}
