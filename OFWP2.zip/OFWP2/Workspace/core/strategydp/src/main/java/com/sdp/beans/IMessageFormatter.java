package com.sdp.beans;

public interface IMessageFormatter {
	String formatMessage(String message);
}
