package com.lmi.beans;

public interface IEngine {
	void start();
}
