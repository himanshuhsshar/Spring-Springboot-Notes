package com.coredi.beans;

public interface IMessageFormatter {
	String formatMessage(String message);
}
